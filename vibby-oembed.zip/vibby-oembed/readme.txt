=== Vibby oEmbed ===
Contributors: vibby
Donate link: http://example.com/
Tags: editor, oembed, vibby
Requires at least: 2.9
Tested up to: 4.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Whitelists Vibby domains to enable vib embeds via pasting URL to visual editor.

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/vibby-oembed` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress
3. You can now paste the Vibby URLs to editor in visual mode, and embed the vibs that way.
